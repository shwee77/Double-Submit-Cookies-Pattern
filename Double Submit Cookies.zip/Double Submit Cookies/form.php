
<?php
session_start();
function generateToken($form)
{
  return setcookie("csrf", base64_encode(openssl_random_pseudo_bytes(32)), time() + 3600, "/");
}
function checkToken($token)
{
    return urldecode($token) ==$_COOKIE['csrf'];
}

generateToken();
if (!$_SESSION["sess"]) {
    header('Location: ./index.php');
    exit();
} else {
    echo 'Welcome Home!';
}
if (isset($_POST['csrf_token']) && isset($_POST['firstname']) && isset($_POST['lastname']))
{
    if (checkToken($_POST['csrf_token']))
    {
      ?>
      <script>alert("Settings Updated");</script>
      <?php

    } else
    {
      ?> <script>alert("Invalide CSRF Token!");</script>
      <?php

    }
}
?>





<style>
.button {
  background-color: #4CAF50;
  color: white;
  padding: 12px 20px;
  border: none;
  border-radius: 4px;
  cursor: pointer;
  }


body {font-family: Arial, Helvetica, sans-serif;}

input[type=text], select, textarea {
    width: 100%;
    padding: 12px;
    border: 1px solid #ccc;
    border-radius: 4px;
    box-sizing: border-box;
    margin-top: 6px;
    margin-bottom: 16px;
    resize: vertical;
}

input[type=submit] {
    background-color: #4CAF50;
    color: white;
    padding: 12px 20px;
    border: none;
    border-radius: 4px;
    cursor: pointer;
}

input[type=submit]:hover {
    background-color: #45a049;
}

.container {
    border-radius: 5px;
    background-color: #f2f2f2;
    padding: 20px;
}
</style>

<script>
function getCookieValue(a) {
    var b = document.cookie.match('(^|;)\\s*' + a + '\\s*=\\s*([^;]+)');
    return b ? b.pop() : '';
}
</script>

</head>
<body>

<h3>Contact Form</h3>
<?php
//session_start();

echo " You are Logged in As :".$_SESSION['sess']?>
<div class="container">
  <form id="loginform" method="POST" action="form.php">
    <label for="fname">First Name</label>
    <input type="text" id="fname" name="firstname" placeholder="Your name..">

    <label for="lname">Last Name</label>
    <input type="text" id="lname" name="lastname" placeholder="Your last name..">

    <label for="country">Country</label>
    <select id="country" name="country">
      <option value="australia">Australia</option>
      <option value="canada">Canada</option>
      <option value="usa">USA</option>
    </select>

    <input id="token2" type="hidden"  name="csrf_token" >

    <input type="submit" value="Submit">
    <a href="./logout.php" class="button">Logout</a>


  </form>
  <script>
  document.getElementById('token2').value=getCookieValue('csrf');
  </script>

</div>

</body>
</html>
